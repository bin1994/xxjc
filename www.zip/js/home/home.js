/**
 * Created by bin on 2016/4/5.
 */
'use strict';
(function () {

  angular.module('home', ['home.ctrl']);

})();
