/**
 * Created by bin on 2016/4/5.
 */
'use strict';
(function () {

  angular.module('account', ['account.list','account.password']);

})();
