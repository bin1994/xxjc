/**
 * Created by bin on 2016/3/30.
 */
'use strict';
(function () {

  angular.module('order', ['order.add','order.list']);

})();
